# College Information Portal

This repository contains my ASP.NET Core MVC project for the subject **Web Technologies with .NET**.

## 📘 Description
The College Information Portal is a web application that allows administrators to manage departments, courses, faculty, students, and events.  
It demonstrates CRUD operations, validation, and database handling using ASP.NET Core MVC and Entity Framework Core.

## ⚙️ How to Run
1. Download the ZIP file from this repository.
2. Extract it to your computer.
3. Open the folder in **Visual Studio Code**.
4. Run:
   ```bash
   dotnet restore
   dotnet run
5. Open https://localhost:5001 in your browser.

## 🧠 Technologies Used

ASP.NET Core MVC (C#)

Entity Framework Core (Code First)

Razor Views

Bootstrap 5 (Styling)

SQLite / MySQL Database

Session & TempData

Visual Studio Code IDE